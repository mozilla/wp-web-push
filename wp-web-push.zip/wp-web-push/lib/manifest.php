{
  "start_url": "/",
  "gcm_sender_id": "<?php echo get_option('webpush_gcm_sender_id'); ?>",
  "gcm_user_visible_only": true
}
